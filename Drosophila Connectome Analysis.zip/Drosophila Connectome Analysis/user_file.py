#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 16:00:59 2024

@author: gabrielgibberd
"""

# All the functions used are in these imported modules.

import ROI_selection_criteria as rsc
import functions_file as fun
import graph_plotting as gp

# This .csv file is in the directory. If you having issues with the program 
# change the working directory to this folder

csv_file_path = "drosophila_connectome.csv"

#%% ROI selection criteria. This code is how the ROI gL(R) was chosen.

#filtering the ROIs in the connectome for only those with more than 5000 connections
roi_list_filtered, filtered_df = rsc.remove_ROI_insufficient_connections(csv_file_path)

#Finding the ROI with the highest edge to node ratio
ROI = rsc.calculate_edge_to_node_ratio(roi_list_filtered, filtered_df)

print('ROI with the highest edge to node ratio: ', ROI)

#%% 1. Create a graph from the entire ROI gL(R)

G = fun.create_gLR_graph(csv_file_path)

#%% 2. Conduct motif analysis on the entire ROI graph and a benchmark set of 
#random graphs

#Note the iterations and sample size of each iteration

iterations = 40
sample_size = 100

#Sample the ROI graph motifs
whole_motif_counts_array = fun.repeated_sampling(G, iterations, sample_size) 

#Create a random benchmark and sample motifs from there
whole_rand_motif_counts_array = fun.repeated_sampling_multiple_randoms(G, iterations, sample_size) 


#plot graph comparing the two motif counts and calculate p-values
establish_graph_title = "Entire ROI Motif Spectrum Compared with the Motif Spectra from 40 Random Models"
establish_graph_colours = ['c', 'y']


gp.plot_from_arrays(whole_motif_counts_array, whole_rand_motif_counts_array, 
                    establish_graph_colours, establish_graph_title)

#p-value calc

establish_p_values = fun.p_values(whole_motif_counts_array,whole_rand_motif_counts_array)

#print p-values:
print("Here are the p-values comparing each motif count of ROI and benchmakr graphs")
for i, value in enumerate(establish_p_values):
    print(f"Motif {i+1} p-value: {value}")

#%% 3. Subset the gL(R) graph into two graphs with edge weights more than 3
#(More graph) and edge weights 3 and under (Less graph).

threshold_weight = 3  

G_more, G_less = fun.subset_graph_by_weight(G, threshold_weight)

#%% 4. Conduct motif analysis on the Less graph and the More graph and compare 
# plots and p-value calculation.

#Sample the Less and More graphs
less_motif_counts_array = fun.repeated_sampling(G_less, iterations, sample_size) 
more_motif_counts_array = fun.repeated_sampling(G_more, iterations, sample_size) 

#plot the motif counts on the same axis to compare them and calculate p-values.
compare_graph_title = "Comparison of motif spectra from both the Less and More graphs"
compare_graph_colours = ['r', 'b']

gp.plot_from_arrays(less_motif_counts_array, more_motif_counts_array, 
                    compare_graph_colours, compare_graph_title)

#p-value calc
compare_p_values = fun.p_values(less_motif_counts_array,more_motif_counts_array)

#print p-values:
print("Here are the p-values comparing each motif count of the Less and More graphs")
for i, value in enumerate(compare_p_values):
    print(f"Motif {i+1} p-value: {value}")
#%% 5. Plot the separate motif counts for the analysis of results.

less_graph_title = 'Motif distribution of Less graph'
less_colour = 'r'

gp.plot_from_array(less_motif_counts_array, less_colour, less_graph_title)


more_graph_title = 'Motif distribution of More graph'
more_colour = 'b'

gp.plot_from_array(more_motif_counts_array, more_colour, more_graph_title)

